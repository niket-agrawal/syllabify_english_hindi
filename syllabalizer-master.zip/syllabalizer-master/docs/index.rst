.. indicsyllabifier documentation master file, created by
   sphinx-quickstart on Fri Sep 13 00:12:10 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

indicsyllabifier
=================

A syllable is a unit of organization for a sequence of speech
sounds.Enter the text for syllabification.  Language of each word will
be detected.

.. automodule:: indicsyllabifier.core
   :members:




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
